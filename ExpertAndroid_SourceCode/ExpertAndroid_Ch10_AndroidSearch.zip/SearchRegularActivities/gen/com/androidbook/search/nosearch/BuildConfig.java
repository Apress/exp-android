/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.search.nosearch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}