/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.densities;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}