package com.androidbook.OpenGL;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.os.SystemClock;

//filename: SimpleTriangleRenderer.java
public class ES20ControlledAnimatedTexturedCubeRenderer extends ES20SingleTextureAbstractRenderer
{
    //A raw native buffer to hold the point coordinates
    private FloatBuffer mFVertexBuffer;
    private FloatBuffer mFTextureBuffer;
    private static final int FLOAT_SIZE_BYTES = 4;
    
    private boolean stopFlag = false;
    private float curAngle = 0;
    private float stoppedAtAngle = 0;
    

//front-face: f1,f2,f3,f4
//starting top-right-anti-clockwise    
//f1(1,1) f2(-1,1) f3(-1,-1) f4(1,-1): z plane 0
    
//back-face: b1,b2,b3,b4
//starting bottom-right-anti-clockwise    
//b1(1,-1) b2(1,1) b3(-1,1) b4(-1,-1) : z plane 1
    private float z = 2.0f;
    private final float[] mTriangleVerticesData = {
    		//1. front-triangles
    		//f1,f2,f3
    		1,1,0,  		-1,1,0,    			-1,-1,0,
    		
    		//f3,f4,f1
    		-1,-1,0, 		1,-1,0,    		1,1,0,    		
    		
    		//2. back-triangles
    		//b1,b2,b3
    		1,-1,z,    		1,1,z,    		-1,1,z,
    		//b3,b4,b1
    		-1,1,z,    		-1,-1,z,    		1,-1,z,
    		
    		//3. right-triangles
    		//b2,f1,f4
    		1,1,z,    		1,1,0,    		1,-1,0,
    		//b2,f4,b1
    		1,1,z,			1,-1,0,			1,-1,z,
    		
    		//4. left-triangles
    		//b3, f2, b4
    		-1,1,z,    		-1,1,0,    		-1,-1,z,
    		//b4 f2 f3
    		-1,-1,z,    		-1,1,0,    		-1,-1,0,
    		
    		//5. top-triangles
    		//b2, b3, f2
    		1,1,z,			-1,1,z,				-1,1,0,
    		//b2, f2, f1
    		1,1,z,			-1,1,0,			1,1,0,
    		
    		//6. bottom-triangles
    		//b1, b4, f3
    		1,-1,z,		-1,-1,z,	-1,-1,0,
    		//b1, f3, f4
    		1,-1,z,		-1,-1,0,	1,-1,0
/*
 */    		
            };

    //f1(1,1) f2(0,1) f3(0,0) f4(1,0) 
    //b1(1,0) b2(1,1) b3(0,1) b4(0,0)
    private final float[] mTextureData = {
    		//1. front-triangles
    		//f1,f2,f3
    		1,0,			0,0,				0,1,
    		//f3,f4,f1
    		0,1, 1,1,1,0, 							
    		
    		//2. back-triangles
    		//b1,b2,b3
    		1,0,	1,1,	0,1,
    		//b3,b4,b1
    		0,1,	0,0,	1,0,
    		
    		//3. right-triangles
    		//b2,f1,f4
    		1,1,	0,1,	0,0,
    		//b2,f4,b1
    		1,1,	0,0,	1,0,
    		
    		//4. left-triangles
    		//b3, f2, b4
    		0,1, 	1,1, 	0,0,
    		//b4 f2 f3
    		0,0, 	1,1, 	1,0,
    		
    		//5. top-triangles
    		//b2, b3, f2
    		1,1, 	0,1, 	0,0,
    		//b2, f2, f1
    		1,1, 	0,0, 	1,0,
    		
    		//6. bottom-triangles
    		//b1, b4, f3
    		1,1,	0,1,	0,0,
    		//b1, f3, f4
    		1,1,	0,0,	1,0
    		/*    		
*/    		
            };
    public ES20ControlledAnimatedTexturedCubeRenderer(Context context) 
    {
    	setupVertexBuffer();
    	setupTextureBuffer();
    }
    private void setupTextureBuffer()
    {
    	//Allocate and handle texture buffer
        ByteBuffer vbb1 = ByteBuffer.allocateDirect(mTextureData.length
                * FLOAT_SIZE_BYTES);
        vbb1.order(ByteOrder.nativeOrder());
        mFTextureBuffer = vbb1.asFloatBuffer();
        mFTextureBuffer.put(mTextureData);
        mFTextureBuffer.position(0);
    }
    
    private void setupVertexBuffer()
    {
    	//Allocate and handle vertex buffer
        ByteBuffer vbb = ByteBuffer.allocateDirect(mTriangleVerticesData.length
                * FLOAT_SIZE_BYTES);
        vbb.order(ByteOrder.nativeOrder());
        mFVertexBuffer = vbb.asFloatBuffer();
        mFVertexBuffer.put(mTriangleVerticesData);
        mFVertexBuffer.position(0);
    }
    private void transferVertexPoints(int vertexPositionHandle)
    {
        GLES20.glVertexAttribPointer(vertexPositionHandle, 3, 
        		GLES20.GL_FLOAT, false,
                0, mFVertexBuffer);
        checkGlError("glVertexAttribPointer maPosition");
        //mFVertexBuffer.position(TRIANGLE_VERTICES_DATA_UV_OFFSET);
        GLES20.glEnableVertexAttribArray(vertexPositionHandle);
        checkGlError("glEnableVertexAttribArray maPositionHandle");
    }

    private void transferTexturePoints(int texturePositionHandle)
    {
        GLES20.glVertexAttribPointer(texturePositionHandle, 2, GLES20.GL_FLOAT, false,
                0, mFTextureBuffer);
        checkGlError("glVertexAttribPointer texture array");
        //mFVertexBuffer.position(TRIANGLE_VERTICES_DATA_UV_OFFSET);
        GLES20.glEnableVertexAttribArray(texturePositionHandle);
        checkGlError("glEnableVertexAttribArray textures");
        //this.bindTextureSamplerToTextureId();
    }
    protected void draw(GL10 gl, int positionHandle)
    {
    	GLES20.glEnable(GLES20.GL_DEPTH_TEST);
    	GLES20.glDepthFunc(GLES20.GL_LESS);
    	transferVertexPoints(positionHandle);
    	transferTexturePoints(getTextureHandle());
    	
        //Break time into 4000 parts
        //each part is .090 so that in 4000 parts it will be 360
        
    	if (stopFlag == true)
    	{
    		//stop rotation
    		curAngle = stoppedAtAngle;
    	}
    	else
    	{
            curAngle += 1.0f;
    	}
    	if (curAngle > 360)
    	{
    		curAngle = 0;
    	}
        
        this.initializeMatrices();
        //Center the cube
        this.trnslate(0,0,-1);
        
        //Rotate it around y axis
        this.rotate(curAngle, 0,-1,0);
        
        //Decenter it to where ever you want
        this.trnslate(0,-2,2);
        
        this.setupMatrices();
        int vertexCount = mTriangleVerticesData.length/3;
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
        checkGlError("glDrawArrays");
    }
    @Override
    protected FrustumDimensions getFrustumDimensions() 
    {
    	return FrustumDimensions.getMedium();
    }
    
    private static final String VERTEX_SHADER_FILENAME = "tex_vertex_shader_1.txt";
    private static final String FRAGMENT_SHADER_FILENAME = "tex_fragment_shader_1.txt";
    @Override
    protected String getFragmentShaderCodeString()
    {
    	return this.getStringFromAssetFile(FRAGMENT_SHADER_FILENAME);
    	//return this.getDefaultFragmentShaderCodeString();
    }
    @Override
    protected String getVertexShaderCodeString()
    {
    	return this.getStringFromAssetFile(VERTEX_SHADER_FILENAME);
    	//return this.getDefaultVertexShaderCodeString();
    }
    public void stop()
    {
    	this.stopFlag = true;
    	this.stoppedAtAngle = curAngle;
    }
    public void start()
    {
    	this.stopFlag = false;
    	this.curAngle = this.stoppedAtAngle;
    }
}
