package com.androidbook.OpenGL;


import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ES20GLCompositeActivity1 extends Activity
{
	private static String tag = "ES20GLCompositeActivity1";
	
   GLSurfaceView mTestHarness = null;
   ES20ControlledAnimatedTexturedCubeRenderer2 mRenderer = null;
   
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        mRenderer = createRenderer();
        mTestHarness = createGLView(mRenderer);
        setContentView(R.layout.gl_composite);
        
        LinearLayout outerView = 
        	(LinearLayout)this.findViewById(R.id.outerViewId);
        View view1 = 
        	this.findViewById(R.id.glViewId);
        outerView.removeView(view1);
        outerView.addView(mTestHarness,0);
        
/*        LayoutInflater lif = this.getLayoutInflater();
        lif.inflate(R.layout.gl_composite, null);
*/        
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){ 
    	super.onCreateOptionsMenu(menu);
 	   	//MenuInflater inflater = getMenuInflater(); //from activity
 	   	//inflater.inflate(R.menu.main_menu, menu);
    	return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
    {
    	return true;
    }
    
    private ES20ControlledAnimatedTexturedCubeRenderer2 
    createRenderer()
    {
    	return new ES20ControlledAnimatedTexturedCubeRenderer2();    	
    }
    
    private GLSurfaceView createGLView(Renderer renderer)
    {
       GLSurfaceView glsView = new GLSurfaceView(this);
       ViewGroup.LayoutParams p = 
    	   new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
    			   0,
    			   3);
       glsView.setLayoutParams(p);
       //glsView.setBackground(R.drawable.shape2);
       //glsView.setBackgroundResource(R.drawable.shape2);
       glsView.setEGLContextClientVersion(2);
      
    	
       glsView.setRenderer(renderer);
        //mTestHarness.setRenderer(new GLES20TestRenderer(this));
        //mTestHarness.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
       glsView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
       return glsView;
    }
    @Override
    protected void onResume() 
    {
    	super.onPause();
    	if (mTestHarness != null)
    	{
    		mTestHarness.onResume();
    	}
    }
    @Override
    protected void onPause() 
    {
    	super.onPause();
    	if (mTestHarness != null)
    	{
    		mTestHarness.onPause();
    	}
    }
	public void showMessage(String tag, String message)
	{
		String s = tag + ":" + message;
		Toast toast = Toast.makeText(this, s, Toast.LENGTH_SHORT);
		toast.show();
		Log.d(tag,message);
	}
	public void stopRotation(View stopButtonView)
	{
		Button stopButton = (Button)stopButtonView;
		String text = stopButton.getText().toString();
		if (text.equalsIgnoreCase("stop"))
		{
			this.mRenderer.stop();
			stopButton.setText("Start");
		}
		else
		{
			this.mRenderer.start();
			stopButton.setText("Stop");
		}
	}
}