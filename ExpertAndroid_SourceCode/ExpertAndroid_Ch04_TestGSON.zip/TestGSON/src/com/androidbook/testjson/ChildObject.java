package com.androidbook.testjson;

public class ChildObject {
	public String name;
	public int age;
	public boolean likesVeggies = false;
	
	public ChildObject(String inName, int inAge)
	{
		name = inName;
		age = inAge;
	}
}
